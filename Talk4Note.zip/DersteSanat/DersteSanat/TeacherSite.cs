﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DersteSanat
{
    class TeacherSite
    {
        public string Id { get; set; }
        public string Ogretmen_kullanici_ismi { get; set; }
        public string Ogretmen_sifre{ get; set; }
        public string Ogretmen_ismi { get; set; }
        public string Ogretmen_soyismi{ get; set; }
    }
}
