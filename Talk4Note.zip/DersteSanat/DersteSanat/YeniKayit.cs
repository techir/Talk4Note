﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DersteSanat
{
    public partial class YeniKayit : Form
    {
        public StudentSite sdsite;
        public Authorization ausite;
        public int kayitflag;
        public string passwordtouse;
        public YeniKayit()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (kayitflag==0)
            {
                try
                {
                    SqlConnection conn = new SqlConnection("Data Source=FFMAC;Initial Catalog=Talk4Note;Integrated Security = true");
                    conn.Open();

                    SqlCommand ada = new SqlCommand("Insert into ogrenci_durum(Id,Isim,Soyisim,Yas,Seviye,ogretmen_kullanici_adi) values (@Id,@isim,@soyisim,@yas,@seviye,@ogretmen_kullanici_adi)", conn);
                    ada.Parameters.AddWithValue("@Id", textBox5.Text);
                    ada.Parameters.AddWithValue("@isim", textBox1.Text);
                    ada.Parameters.AddWithValue("@soyisim", textBox2.Text);
                    ada.Parameters.AddWithValue("@yas", textBox3.Text);
                    ada.Parameters.AddWithValue("@seviye", textBox4.Text);
                    ada.Parameters.AddWithValue("@ogretmen_kullanici_adi", this.sdsite.autpage.textBox1.Text);
                    ada.ExecuteScalar();
                    conn.Close();
                    MessageBox.Show("Yeni öğrenci başarıyla oluşturuldu.", "Onay", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBoxclearer();
                }
                catch (Exception)
                {

                    MessageBox.Show("Beklenmeyen bir hata oluştu! Lütfen Tekrar deneyiniz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxclearer();
                }
            }
            else
            {
                try
                {
                    SqlConnection conn = new SqlConnection("Data Source=FFMAC;Initial Catalog=Talk4Note;Integrated Security = true");
                    conn.Open();

                    SqlCommand ada = new SqlCommand("Insert into kullanici_bilgileri(kullanici_adi,kullanici_sifresi) values (@username,@password)", conn);
                    
                    string encryptedpassword = StringCipher.Encrypt(tb_ogretmen2.Text,passwordtouse);
                    ada.Parameters.AddWithValue("@username", tb_ogretmen1.Text);
                    ada.Parameters.AddWithValue("@password", encryptedpassword.ToString()); 
                    ada.ExecuteScalar();
                    textBoxclearer();
                    MessageBox.Show("Yeni öğretmen hesabı başarıyla oluşturuldu.", "Onay", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                catch (Exception)
                {

                    MessageBox.Show("Beklenmeyen bir hata oluştu! Lütfen Tekrar deneyiniz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxclearer();
                }
            }
            
            

        }

        private void textBoxclearer()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            tb_ogretmen1.Clear();
            tb_ogretmen2.Clear();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (kayitflag==0)
            {
                this.sdsite.listView1.Clear();
                this.sdsite.fillthelistview();
                this.sdsite.Enabled = true;
                this.Close();
                this.Dispose();
            }
            else
            {

                this.ausite.Enabled = true;
                this.Close();
                this.Dispose();
            }
            
            

        }
    }
}
