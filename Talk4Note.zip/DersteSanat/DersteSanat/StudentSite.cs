﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DersteSanat
{
    public partial class StudentSite : Form
    {
        public Authorization autpage;
        public Form1 teachpage;
        public int sqlflag = 0;

        public StudentSite()
        {
            InitializeComponent();
            if (sqlflag == 1)
            {
                fillthelistview();
            }
            
           

        }

        internal void fillthelistview()
        {
            OgrenciBilgileri ogrenci = new OgrenciBilgileri();
            SqlConnection conn = new SqlConnection("Data Source=FFMAC;Initial Catalog=Talk4Note;Integrated Security = true");
            conn.Open();
                 
            SqlDataAdapter ada = new SqlDataAdapter("select Checkbox,Id,Isim,Soyisim,Yas,Seviye,Ders_sayisi,Verilen_odev from ogrenci_durum where ogretmen_kullanici_adi=@ogretmen", conn);
            ada.SelectCommand.Parameters.Add("@ogretmen", SqlDbType.VarChar, 20).Value = this.autpage.textBox1.Text.ToString();
            DataTable dt = new DataTable();
            ada.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];
                ListViewItem listitem = new ListViewItem(dr["Checkbox"].ToString());
                listitem.SubItems.Add(dr["Id"].ToString());
                listitem.SubItems.Add(dr["Isim"].ToString());
                listitem.SubItems.Add(dr["Soyisim"].ToString());
                listitem.SubItems.Add(dr["Yas"].ToString());
                listitem.SubItems.Add(dr["Seviye"].ToString());
                listitem.SubItems.Add(dr["Ders_sayisi"].ToString());
                listitem.SubItems.Add(dr["Verilen_odev"].ToString());
                listView1.Items.Add(listitem);
            }

            conn.Close();

            
            listView1.Columns.Add("");
            listView1.Columns.Add("Id", -2, HorizontalAlignment.Center);
            listView1.Columns.Add("İsim", -2, HorizontalAlignment.Center);
            listView1.Columns.Add("Soyisim", -2, HorizontalAlignment.Center);
            listView1.Columns.Add("Yaş", -2, HorizontalAlignment.Center);
            listView1.Columns.Add("Seviye", -2, HorizontalAlignment.Center);
            listView1.Columns.Add("Ders Sayısı", -2, HorizontalAlignment.Center);
            listView1.Columns.Add("Verilen Ödev", -2, HorizontalAlignment.Center);

            listView1.CheckBoxes = true;

            listView1.Columns[1].Tag = 1;
            listView1.Columns[2].Tag = 1;
            listView1.Columns[3].Tag = 1;
            listView1.Columns[4].Tag = 1;
            listView1.Columns[5].Tag = 1;
            listView1.Columns[6].Tag = 1;

            listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
            listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            listView1.FullRowSelect = true;
        }

        private void StudentSite_Load(object sender, EventArgs e)
        {
            this.Opacity = 0;
            this.Visible = false;
            autpage = new Authorization();
            autpage.mainw =this;
            autpage.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.autpage.textBox1.Clear();
            this.autpage.textBox2.Clear();
            this.autpage.Visible = true;
            this.autpage.Opacity = 100;
            this.Opacity = 0;
            this.Visible = false;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ListView.CheckedListViewItemCollection checkedItems = listView1.CheckedItems;
            foreach (ListViewItem item in checkedItems)
            {
                string a = item.SubItems[1].Text;
            }

            this.Opacity = 0;
            this.Visible = false;
            teachpage = new Form1();
            teachpage.mainf = this;
           
            

            teachpage.Show();

        }

        private void yeniÖğrenciKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayit yenikayit = new YeniKayit();
            yenikayit.sdsite = this;
            this.Enabled = false;
            yenikayit.kayitflag = 0;
            visibility(yenikayit);
            yenikayit.Show();
          
        }

        private void visibility(YeniKayit yenikayit)
        {
            yenikayit.ogretmen1.Visible = false;
            yenikayit.ogretmen2.Visible = false;
            yenikayit.tb_ogretmen1.Visible = false;
            yenikayit.tb_ogretmen2.Visible = false;
        }
    }
}
