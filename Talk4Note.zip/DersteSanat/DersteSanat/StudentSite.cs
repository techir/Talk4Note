﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DersteSanat
{
    public partial class StudentSite : Form
    {
        public Authorization autpage;
        public Form1 teachpage;

        public StudentSite()
        {
            InitializeComponent();
            

            OgrenciBilgileri ogrenci = new OgrenciBilgileri();

            ogrenci.Id = 1;
            ogrenci.Isim = "Can";
            ogrenci.Soyisim = "Atmaca";
            ogrenci.yas = 7;
            ogrenci.seviye = 1;
            ogrenci.ders_sayisi = 7;
            ogrenci.verilen_ödev = "W. A. Mozart - KV 18 - Symphony No. 3 in E flat major";
            //burayı liste yapıp foreach ile listview'a ekleyeceğim. Ayrıca datalar da db'den...


            listView1.Columns.Add("");
            listView1.Columns.Add("Id", -2, HorizontalAlignment.Center);
            listView1.Columns.Add("İsim", -2, HorizontalAlignment.Center);
            listView1.Columns.Add("Soyisim", -2, HorizontalAlignment.Center);
            listView1.Columns.Add("Yaş", -2, HorizontalAlignment.Center);
            listView1.Columns.Add("Seviye", -2, HorizontalAlignment.Center);
            listView1.Columns.Add("Ders Sayısı", -2, HorizontalAlignment.Center);
            listView1.Columns.Add("Verilen Ödev", -2, HorizontalAlignment.Center);

            listView1.CheckBoxes = true;

            listView1.Columns[1].Tag = 1;
            listView1.Columns[2].Tag = 1;
            listView1.Columns[3].Tag = 1;
            listView1.Columns[4].Tag = 1;
            listView1.Columns[5].Tag = 1;
            listView1.Columns[6].Tag = 1;

            ListViewItem item1 = new ListViewItem(new[] { "",ogrenci.Id.ToString(), ogrenci.Isim, ogrenci.Soyisim, ogrenci.yas.ToString(), ogrenci.seviye.ToString(), ogrenci.ders_sayisi.ToString(), ogrenci.verilen_ödev });
            listView1.Items.Add(item1);
            listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
            listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            listView1.FullRowSelect = true;

        }
        

        private void StudentSite_Load(object sender, EventArgs e)
        {
            this.Opacity = 0;
            this.Visible = false;
            autpage = new Authorization();
            autpage.mainw =this;
            autpage.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.autpage.textBox1.Clear();
            this.autpage.textBox2.Clear();
            this.autpage.Visible = true;
            this.autpage.Opacity = 100;
            this.Opacity = 0;
            this.Visible = false;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ListView.CheckedListViewItemCollection checkedItems = listView1.CheckedItems;
            foreach (ListViewItem item in checkedItems)
            {
                string a = item.SubItems[1].Text;
            }

            this.Opacity = 0;
            this.Visible = false;
            teachpage = new Form1();
            teachpage.mainf = this;
           
            

            teachpage.Show();

        }
    }
}
