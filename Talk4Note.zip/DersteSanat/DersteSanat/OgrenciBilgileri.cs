﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DersteSanat
{
    class OgrenciBilgileri
    {
        public int Id { get; set; }
        public string Isim { get; set; }
        public string Soyisim { get; set; }
        public int yas{ get; set; }
        public int seviye { get; set; }
        public int ders_sayisi { get; set; }
        public string verilen_ödev { get; set; }
    }
}
