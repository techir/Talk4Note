﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace DersteSanat
{
    public partial class Authorization : Form
    {
        public StudentSite studentpage;

        public Authorization()
        {
            InitializeComponent();
        }
        public StudentSite mainw;

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TeacherSite kullanici_girisi = new TeacherSite();
            kullanici_girisi.Ogretmen_kullanici_ismi = "pinar.ulug";
            kullanici_girisi.Ogretmen_sifre = "12345";
            

            if (textBox1.Text == kullanici_girisi.Ogretmen_kullanici_ismi && textBox2.Text== kullanici_girisi.Ogretmen_sifre)
            {
                this.mainw.Opacity = 100;
                this.mainw.Visible = true;
                this.mainw.textBox1.Text = textBox1.Text.Replace(".", " ").ToUpper();
                this.Opacity=0;
                this.Visible = false;
            }
            else
            {
                MessageBox.Show("Kullanıcı ismi veya şifre yanlış. Lütfen Tekrar deneyiniz.");
                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private void hakkımızdaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Yaratan: Altuğ Yıldırım" + System.Environment.NewLine + "Tarih: 06.01.2018" + System.Environment.NewLine + "Versiyon: 1.0", "Hakkımızda");
        }

        private void Authorization_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void yardımToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Yaratan: Altuğ Yıldırım" + System.Environment.NewLine + "Tarih: 06.01.2018" + System.Environment.NewLine + "Versiyon: 1.0", "Info",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
    }
}
