﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace DersteSanat
{
    public partial class Authorization : Form
    {
        public StudentSite studentpage;
        public string passwordtouse;
        public Authorization()
        {
            InitializeComponent();
        }
        public StudentSite mainw;

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            getAuthorization();
        }

        private void getAuthorization()
        {
            SqlConnection conn = new SqlConnection("Data Source=FFMAC;Initial Catalog=Talk4Note;Integrated Security = true");
            conn.Open();
           
            SqlCommand ada = new SqlCommand("select kullanici_sifresi from kullanici_bilgileri where kullanici_adi=@username", conn);
            ada.Parameters.AddWithValue("@username", textBox1.Text);
            
            try
            {
                string result = ada.ExecuteScalar().ToString();
                passwordtouse = "12345";
                string decryptedstring = StringCipher.Decrypt(result, passwordtouse);
                if (decryptedstring == textBox2.Text)
                {
                    this.mainw.listView1.Clear();
                    this.mainw.sqlflag = 1;
                    this.mainw.fillthelistview();
                    this.mainw.Opacity = 100;
                    this.mainw.Visible = true;
                    this.mainw.textBox1.Text = textBox1.Text.Replace(".", " ").ToUpper();
                    this.Opacity = 0;
                    this.Visible = false;
                }
                else
                {
                    MessageBox.Show("Kullanıcı ismi veya şifre yanlış. Lütfen Tekrar deneyiniz.");
                    textBox1.Clear();
                    textBox2.Clear();
                    this.mainw.sqlflag = 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
            conn.Close();
        }

        private void hakkımızdaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Yaratan: Altuğ Yıldırım" + System.Environment.NewLine + "Tarih: 06.01.2018" + System.Environment.NewLine + "Versiyon: 1.0", "Hakkımızda");
        }

        private void Authorization_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void yardımToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Yaratan: Altuğ Yıldırım" + System.Environment.NewLine + "Tarih: 06.01.2018" + System.Environment.NewLine + "Versiyon: 1.0", "Info",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void yeniKullanıcıYaratToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.textBox1.Clear();
            this.textBox2.Clear();
            YeniKayit Yenikayit_ogretmen = new YeniKayit();
            Yenikayit_ogretmen.ausite = this;
            this.Enabled = false;
            Yenikayit_ogretmen.passwordtouse = this.passwordtouse;
            Yenikayit_ogretmen.kayitflag = 1;
            Visibility(Yenikayit_ogretmen);   
            Yenikayit_ogretmen.Show();
        }

        private void Visibility(YeniKayit item)
        {
            item.textBox1.Visible = false;
            item.textBox2.Visible = false;
            item.textBox3.Visible = false;
            item.textBox4.Visible = false;
            item.textBox5.Visible = false;
            item.label1.Visible = false;
            item.label2.Visible = false;
            item.label3.Visible = false;
            item.label4.Visible = false;
            item.label5.Visible = false;
        }
    }
}
