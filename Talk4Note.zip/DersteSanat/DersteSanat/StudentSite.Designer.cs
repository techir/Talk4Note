﻿namespace DersteSanat
{
    partial class StudentSite
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentSite));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.detaylarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.raporlarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.haftalıkRaporToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aylıkRaporToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dersÇizelgesiEntegrasyonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sorunBildirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iletişimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.öğrenciVelileriToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tanSağtürkAkademiBürolarıToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.button4 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(7, 106);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(173, 31);
            this.textBox1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Aktif Öğretmen:";
            // 
            // listView1
            // 
            this.listView1.AllowColumnReorder = true;
            this.listView1.CheckBoxes = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(379, 58);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(644, 561);
            this.listView1.TabIndex = 3;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 191);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(168, 83);
            this.button1.TabIndex = 4;
            this.button1.Text = "Dersi Başlat";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 320);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(168, 83);
            this.button2.TabIndex = 5;
            this.button2.Text = "Rapor Al";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 527);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(224, 39);
            this.button3.TabIndex = 6;
            this.button3.Text = "Çıkış";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.detaylarToolStripMenuItem,
            this.iletişimToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1064, 40);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // detaylarToolStripMenuItem
            // 
            this.detaylarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.raporlarToolStripMenuItem,
            this.dersÇizelgesiEntegrasyonToolStripMenuItem,
            this.sorunBildirToolStripMenuItem});
            this.detaylarToolStripMenuItem.Name = "detaylarToolStripMenuItem";
            this.detaylarToolStripMenuItem.Size = new System.Drawing.Size(115, 36);
            this.detaylarToolStripMenuItem.Text = "Detaylar";
            // 
            // raporlarToolStripMenuItem
            // 
            this.raporlarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.haftalıkRaporToolStripMenuItem,
            this.aylıkRaporToolStripMenuItem});
            this.raporlarToolStripMenuItem.Name = "raporlarToolStripMenuItem";
            this.raporlarToolStripMenuItem.Size = new System.Drawing.Size(263, 38);
            this.raporlarToolStripMenuItem.Text = "Raporlar";
            // 
            // haftalıkRaporToolStripMenuItem
            // 
            this.haftalıkRaporToolStripMenuItem.Name = "haftalıkRaporToolStripMenuItem";
            this.haftalıkRaporToolStripMenuItem.Size = new System.Drawing.Size(264, 38);
            this.haftalıkRaporToolStripMenuItem.Text = "Haftalık Rapor";
            // 
            // aylıkRaporToolStripMenuItem
            // 
            this.aylıkRaporToolStripMenuItem.Name = "aylıkRaporToolStripMenuItem";
            this.aylıkRaporToolStripMenuItem.Size = new System.Drawing.Size(264, 38);
            this.aylıkRaporToolStripMenuItem.Text = "Aylık Rapor";
            // 
            // dersÇizelgesiEntegrasyonToolStripMenuItem
            // 
            this.dersÇizelgesiEntegrasyonToolStripMenuItem.Name = "dersÇizelgesiEntegrasyonToolStripMenuItem";
            this.dersÇizelgesiEntegrasyonToolStripMenuItem.Size = new System.Drawing.Size(263, 38);
            this.dersÇizelgesiEntegrasyonToolStripMenuItem.Text = "Ders Çizelgesi";
            // 
            // sorunBildirToolStripMenuItem
            // 
            this.sorunBildirToolStripMenuItem.Name = "sorunBildirToolStripMenuItem";
            this.sorunBildirToolStripMenuItem.Size = new System.Drawing.Size(263, 38);
            this.sorunBildirToolStripMenuItem.Text = "Sorun Bildir";
            // 
            // iletişimToolStripMenuItem
            // 
            this.iletişimToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.öğrenciVelileriToolStripMenuItem1,
            this.tanSağtürkAkademiBürolarıToolStripMenuItem1});
            this.iletişimToolStripMenuItem.Name = "iletişimToolStripMenuItem";
            this.iletişimToolStripMenuItem.Size = new System.Drawing.Size(103, 36);
            this.iletişimToolStripMenuItem.Text = "İletişim";
            // 
            // öğrenciVelileriToolStripMenuItem1
            // 
            this.öğrenciVelileriToolStripMenuItem1.Name = "öğrenciVelileriToolStripMenuItem1";
            this.öğrenciVelileriToolStripMenuItem1.Size = new System.Drawing.Size(427, 38);
            this.öğrenciVelileriToolStripMenuItem1.Text = "Öğrenci Velileri";
            // 
            // tanSağtürkAkademiBürolarıToolStripMenuItem1
            // 
            this.tanSağtürkAkademiBürolarıToolStripMenuItem1.Name = "tanSağtürkAkademiBürolarıToolStripMenuItem1";
            this.tanSağtürkAkademiBürolarıToolStripMenuItem1.Size = new System.Drawing.Size(427, 38);
            this.tanSağtürkAkademiBürolarıToolStripMenuItem1.Text = "Tan Sağtürk Akademi Büroları";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(12, 464);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(224, 39);
            this.button4.TabIndex = 8;
            this.button4.Text = "Oturumu Kapat";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // StudentSite
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1064, 785);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "StudentSite";
            this.Text = "Tan Sağtürk Akademi";
            this.Load += new System.EventHandler(this.StudentSite_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem detaylarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem raporlarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem haftalıkRaporToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aylıkRaporToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dersÇizelgesiEntegrasyonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sorunBildirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iletişimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem öğrenciVelileriToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tanSağtürkAkademiBürolarıToolStripMenuItem1;
        public System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button4;
    }
}