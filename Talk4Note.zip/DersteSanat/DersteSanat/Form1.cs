﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Threading;
using System.Diagnostics;
using System.IO;
using SpeechLib.Models;
using SpeechLib.Recognition;
using SpeechLib.Synthesis;


namespace DersteSanat
{
    public partial class Form1 : Form
    {
        public StudentSite mainf;
        public Form1()
        {
            InitializeComponent();
        }
        SpeechSynthesizer synt = new SpeechSynthesizer();
        PromptBuilder pbuilder = new PromptBuilder();
        //SpeechRecognitionEngine Rengine = new SpeechRecognitionEngine();
        SpeechLib.Recognition.SpeechRecognition Rengine=new SpeechLib.Recognition.SpeechRecognition();

        string path = @"C:\Altug\DersteNot.txt";
        int sol_el_hata_counter=0;

        private void button1_Click(object sender, EventArgs e)
        {
            Choices list = new Choices();
            list.Add("Hello", "exit", "one", "open chrome");
            Grammar gramer = new Grammar(new GrammarBuilder(list));
            try
            {
                
                Rengine.SpeechRecognitionEngine.RequestRecognizerUpdate();
                Rengine.SpeechRecognitionEngine.LoadGrammar(gramer);
                Rengine.SpeechRecognitionEngine.SpeechRecognized += Regine_SpeechRecognized;
                Rengine.SetInputToDefaultAudioDevice();
                Rengine.SpeechRecognitionEngine.RecognizeAsync(RecognizeMode.Multiple);
                
                


            }
            catch (Exception)
            {

                throw;
            }
        }

        private void Regine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            switch (e.Result.Text)
            {
                case "open chrome":
                    System.Diagnostics.Process.Start(@"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe");
                    pbuilder.ClearContent();
                    pbuilder.AppendText("very well");
                    synt.Speak(pbuilder);
                    break;
                case "exit":
                    Application.Exit();
                    break;
                case "one":
                    if (!File.Exists(path))
                    {
                        File.Create(path);
                        TextWriter tw = new StreamWriter(path);
                        sol_el_hata_counter++;
                        tw.WriteLine("Sol Elde hata bulundu. Hata sayısı: " + sol_el_hata_counter + " Tarih: " + DateTime.Now.ToString("MM/dd/yyyy"));
                        tw.Close();
                    }
                    else if (File.Exists(path))
                    {
                        using (var tw = new StreamWriter(path, true))
                        {
                            tw.WriteLine("Sol Elde hata bulundu. Hata sayısı: "+sol_el_hata_counter +" Tarih: "+ DateTime.Now.ToString("MM/dd/yyyy"));
                            tw.Close();
                            sol_el_hata_counter++;
                            pbuilder.ClearContent();
                            pbuilder.AppendText("understood");
                            synt.Speak(pbuilder);
                        }
                    }
                    break;
                default:
                    break;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Rengine.Pause();


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //this.Opacity = 0;
            //Authorization aut = new Authorization();  
            //aut.mainw=this;
            //aut.Show();
            
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Rengine.Resume();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Rengine.Stop();
            this.Opacity = 0;
            this.Visible = false;
            this.mainf.Visible = true;
            this.mainf.Opacity = 100;

        }
    }
}
